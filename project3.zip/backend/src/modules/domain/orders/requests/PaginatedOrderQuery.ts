import { PaginatedQuery } from '../../../common/controllers';

export interface PaginatedOrderQuery extends PaginatedQuery {
  id: string;
}
