export interface Query {
  relations: string[];
}
